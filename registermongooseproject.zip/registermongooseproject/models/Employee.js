let mongoose = require('mongoose');
let empSchema = mongoose.Schema(
    {
        Name:
        {
            type: String,
            required: true
        },
        email:
        {
            type: String,
            required: "Email is required"
        },
        technology:
        {
            type: String,
            required: true
        },
        address:
        {
            type: String,
            required: true
        },
    });
module.export= mongoose.model("Employees",empSchema);