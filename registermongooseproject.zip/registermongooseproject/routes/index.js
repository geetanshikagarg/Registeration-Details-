var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var empModel = mongoose.model("Employees");


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.post('/register',function(req,res)
{
  var empData =new empModel(req.body)
  empModel.create(empData,function(err,result)
  {
    if(err)
      throw err;
    console.log("Data Inserted");
    res.redirect('/display');
  });
});
router.get('/display',function(req,res)
{
  empModel.find({},function(err,result)
  {
   if(err)
     throw err;
   res.render('display',{"result":result});
});
});
router.get('/delete',function(req,res)
{
  var id =mongoose.Types.ObjectId(req.query.id);
    empModel.remove({_id:id},function(err,result)
    {
      if(err)
        throw err;
      res.redirect('/display');
    });
});
router.get('/edit',function(req,res)
{
  var id =mongoose.Types.ObjectId(req.query.id);
    empModel.find({_id:id},function(err,result)
    {
      if(err)
        throw err;
      res.render('edit',{"result":result});
    });
});
router.post('/editDetails',function(req,res)
{
  var id =mongoose.Types.ObjectId(req.body.id);
  
  var newDoc=
  { "name":req.body.Name,
    "email":req.body.email,
    "technology":req.body.technology,
    "address":req.body.address
  }
  
empModel.update({_id:id},newDoc,function (err,response) 
{
  if(err)
  throw err;
res.redirect('/display');
})
})

router.get('/addRecord',function(req,res){
 res.redirect('/');
})

module.exports = router;
